package com.example.janitri_innovations_amith_upadhya.models

data class patient (
    val name:String?=null,
    val age:String?=null,
    val phoneno:String?=null
        )